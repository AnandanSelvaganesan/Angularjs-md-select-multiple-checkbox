import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';
import { AppService } from '../app.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  newForm: FormGroup;
  parameter: FormControl;
  parameter2: FormControl;
  parameter3: FormControl;
  parameter4: FormControl;
  parameterGroup1: FormControl;
  parameterGroup2: FormControl;
  parameterGroup3: FormControl;
  parameterGroup4: FormControl;
  formSubmited = false;  
  
  constructor(private fb: FormBuilder, private appservice: AppService) { }

  ngOnInit() {
    this.parameter = this.fb.control('any', Validators.required);
    this.parameter2 = this.fb.control('any', Validators.required);
    this.parameter3 = this.fb.control('any', Validators.required);
    this.parameter4 = this.fb.control('', Validators.required);
    this.parameterGroup1 = this.fb.control('', Validators.required);
    this.parameterGroup2 = this.fb.control('any', Validators.required);
    this.parameterGroup3 = this.fb.control('any', Validators.required);
    this.parameterGroup4 = this.fb.control('any', Validators.required);

    this.newForm = this.fb.group({
      parameter: this.parameter,
      parameter2: this.parameter2,
      parameter3: this.parameter,
      parameter4: this.parameter4,
      parameterGroup1: this.parameterGroup1,
      parameterGroup2: this.parameterGroup2,
      parameterGroup3: this.parameterGroup3,
      parameterGroup4: this.parameterGroup4
    });

  }

  onSubmit() {
    this.formSubmited = true;
    if(this.newForm.valid) {
      console.log(this.newForm.value);
      this.formSubmited = false;
    }
  }

}
