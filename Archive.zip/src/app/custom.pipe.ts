import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'filterByValue'})
export class FilterByStatusPipe implements PipeTransform {
    transform(list : any, id: string): any[] {
        if (list) {
            if(id === 'all') {
              return list;
            }
            return list.filter((item: any) => item.id === id);
        }
    }
}

@Pipe({name: 'filterByCount'})
export class FilterByCountPipe implements PipeTransform {
    transform(list : any, count: string): any[] {
        if (list) {
            if(count === 'all') {
              return list;
            }
            return list.slice(0, count);
        }
    }
}