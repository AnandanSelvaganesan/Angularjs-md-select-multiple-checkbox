import { Component, OnInit } from '@angular/core';
import { AppService } from '../app.service';
import { HttpErrorResponse } from '@angular/common/http';
import { throwError } from 'rxjs';

@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {

  list = [];
  selectedValue = 'all';
  
  constructor(private appservice:AppService) { }

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.appservice.getJsonData().subscribe(res => {
      this.list = res.map(item => {
        return {
          id: item.id + '',
          title: item.title,
          body: item.body
        }
      });
    },
    err => this.handleError(err),
    () => console.log('Completed')
  )}

  handleError(error: HttpErrorResponse) {
    console.log(error.status);  

    if(error.status === 404)  
          console.log('This Post Is Already Been Deleted');  
        else {  
          // We wanna display generic error message and log the error  
          alert('An Unexpected Error Occured.');  
          console.log(error);  
        }  

    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError(
      'Something bad happened; please try again later.');
  };
  
  ChangingValue(evt) {
    this.selectedValue =evt.target.value;
    //console.log(evt.target.value);
  }

}
